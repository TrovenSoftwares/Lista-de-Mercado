
DROP INDEX idx_markets_user_id;
ALTER TABLE markets DROP COLUMN user_id;
