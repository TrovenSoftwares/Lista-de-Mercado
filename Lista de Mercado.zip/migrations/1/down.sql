
DROP INDEX idx_list_markets_market_id;
DROP INDEX idx_list_markets_list_id;
DROP INDEX idx_items_list_id;
DROP TABLE items;
DROP TABLE list_markets;
DROP TABLE lists;
DROP TABLE markets;
